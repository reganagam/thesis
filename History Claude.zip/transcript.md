# Transkrip Diskusi Perancangan Tesis

## Dual-Stage Hierarchical Breslow Classification dengan Bayesian Uncertainty Gatekeeper

| | |
|---|---|
| **Peneliti** | Regan Agam |
| **NIM** | 24/PTK/552177/16439 |
| **Program** | M.Sc. Teknik Elektro |
| **Paper rujukan** | Dominguez-Morales dkk., *IEEE J. Biomed. Health Inform.*, vol. 29, no. 1, Jan 2025 |
| **Periode diskusi** | 3 Agustus 2026 |
| **Target penyelesaian** | 30 September 2026 |
| **Jumlah putaran** | 6 pertanyaan — dari evaluasi rancangan sampai pembangkitan codebase |

---

## Daftar Isi

1. [Evaluasi Awal Rancangan Tesis](#bagian-1)
2. [Repositori GitHub Paper Rujukan sebagai Referensi](#bagian-2)
3. [Kode Pipeline & Pertanyaan Penyimpanan Model](#bagian-3)
4. [Verifikasi Metadata Dataset & Blueprint Final](#bagian-4)
5. [Pembangkitan Codebase Lengkap](#bagian-5)
6. [Lampiran](#lampiran)

---

<div style="page-break-after: always;"></div>

# Bagian 1 — Evaluasi Awal Rancangan Tesis {#bagian-1}

## Pertanyaan

> Saya ingin mendiskusikan rancangan thesis saya tersebut, landasan utamanya dari paper Juan di atas, bagaimana menurutmu? Analisis mendalam untuk pengerjaan sampai September nanti.

**Berkas terlampir:**

- `Melanoma_Breslow_Thickness_Classification_Using_Ensemble-Based_Knowledge_Distillation_With_Semi-Supervised_Convolutional_Neural_Networks.pdf`
- Dua dokumen rancangan tesis (draft blueprint) — lihat Lampiran A

## Jawaban

Rancangan Anda kokoh secara konsep, dan ada satu fakta yang belum Anda manfaatkan: **paper Dominguez-Morales secara eksplisit menyebut dual-stage pipeline sebagai future work mereka** (di bagian Discussion, setelah mereka membahas rendahnya precision kelas Mis pada multiclass — mereka menulis bahwa ide mengklasifikasi Mis/Miv dulu lalu memberi hasil Miv ke model BT kedua akan dipertimbangkan sebagai penelitian lanjutan). Ini amunisi terkuat untuk Bab 1: research gap-nya bukan klaim Anda sendiri, tapi diakui penulis paper rujukan.

### 1. Koreksi faktual: Kawahara ADA di dalam 5-fold CV mereka

Total 1449 gambar berlabel = 868 (VRUH) + 193 (Polesie) + 141 (ISIC berlabel) + **247 (Kawahara)**. Buktinya, Kawahara muncul sebagai baris di Tabel IV, VI, dan VIII (breakdown per-dataset dari hasil cross-validation). *External test set* mereka adalah entitas lain: 153 kasus / 462 gambar (144 Mis, 199 Miv&lt;0.8, 149 Miv≥0.8) yang tidak diberi nama di teks.

Implikasinya:

- Keputusan mengunci Kawahara sebagai zero-shot hold-out itu **sah dan bahkan lebih ketat**, tapi harus dinyatakan sebagai *deviasi desain yang disengaja*, bukan sebagai "mengikuti paper".
- Angka Anda tidak akan apple-to-apple dengan angka mereka. Data latih Anda tinggal ~1202 gambar (~641 kasus).
- Proxy 0.76 mm untuk Derm7pt sudah benar. Tapi catat sebagai limitasi: kasus di pita 0.76–0.80 mm akan salah dilabeli ≥0.8.

### 2. Risiko terbesar: evaluasi Gatekeeper bisa dianggap sirkular

Kalau Anda membuang 10% sampel dengan varians tertinggi lalu melaporkan akurasi pada 90% sisanya, akurasi **hampir pasti naik** — untuk metrik ketidakpastian apa pun, bahkan yang buruk. Jadi "Skenario C > Skenario B" bukan bukti apa-apa selama coverage-nya berbeda.

Agar klaim bertahan, Skenario C harus dibandingkan pada **coverage yang sama** melawan pembanding murah:

| Pembanding | Kenapa wajib ada |
|---|---|
| **Random rejection** 10% | Lantai absolut. Kalau MC Dropout tidak jauh di atas ini, novelty gugur. |
| **Max Softmax Probability (MSP)** | Baseline paling kuat dan paling murah (1 forward pass). |
| **Predictive entropy** | Sepupu MSP. |
| **Mutual information / BALD** | Pemisah aleatoric vs epistemic yang lebih benar. |

Metriknya bukan "akurasi setelah buang 10%", tapi **Risk–Coverage curve** dan **AURC**.

Tambahan yang murah tapi meyakinkan: dari sampel yang di-*reject*, berapa persen yang sebenarnya salah diprediksi Stage 1? Lalu hitung **AUROC deteksi error**.

Dan satu baris eksperimen lagi yang wajib: **Flat multiclass + rejection**. Tanpa ini, penguji bisa bilang kenaikan akurasi datang dari rejection saja.

### 3. Threshold persentil harus lahir dari validasi, bukan dari test

Kalau Anda mengurutkan varians pada test fold lalu memotong di persentil 90, itu **kebocoran informasi**.

Desain yang benar (nested):

1. Di dalam tiap fold latih, sisihkan validation split.
2. Hitung distribusi varians pada validation → tentukan nilai absolut persentil-90.
3. **Bekukan** angka itu, terapkan sebagai cut-off tetap ke test fold.
4. Laporkan coverage aktualnya — ini yang membuat hasil kredibel.

### 4. Dua celah desain pada pipeline

**a. Gatekeeper hanya menjaga cabang Miv.** Padahal error paling berbahaya secara klinis adalah kebalikannya: Miv ≥0.8 mm yang diprediksi Mis — pasien kehilangan sentinel node biopsy. Minimal, pasang gatekeeper simetris.

**b. Mismatch train/inference di Stage 2.** Anda melatih Stage 2 dengan Miv *ground truth*, tapi saat inferensi ia menerima Miv *hasil prediksi*. Solusi: latih Stage 2 pada sampel yang **diprediksi Miv oleh Stage 1 secara out-of-fold**.

### 5. Bereskan inkonsistensi Flipout vs MC Dropout

Pilih **MC Dropout saja**. Catatan teknis: **ResNet-50 torchvision tidak punya dropout sama sekali**. Alternatif lebih baik: **DenseNet-121 dengan `drop_rate=0.2`**.

### 6. Reality check hardware — over-engineering di tempat yang salah

Dengan ~1200 gambar 224×224 dan ResNet-50, RTX 4060 8GB **sangat berlebihan**. Estimasi: satu konfigurasi selesai dalam hitungan menit.

- AMP silakan dinyalakan, tapi **jangan jual sebagai kontribusi tesis**.
- Anggaran komputasi yang bebas **alihkan ke pengulangan**: 5-fold × 5 seed, agar bisa uji Wilcoxon.

### 7. Soal membuang semi-supervised learning

Pertahankan keputusan supervised-only demi kebersihan eksperimen, tapi nyatakan bahwa pembanding Anda adalah **jalur supervised** paper mereka. Siapkan SSL sebagai eksperimen opsional, bukan critical path.

### 8. Preprocessing: paper mereka tidak melakukannya

Jadikan preprocessing sebagai **ablasi terpisah**. Ganti Gray-World dengan **Shades of Gray (Minkowski p=6)**.

### 9. Kalibrasi framing novelty

Novelty Anda bersifat **aplikatif dan empiris**. Mengklaim "double novelty metodologis" justru mengundang serangan yang tidak perlu.

### Timeline realistis (2 Agustus → 30 September)

| Minggu | Fokus | Deliverable |
|---|---|---|
| **1** (3–9 Ags) | Kirim permintaan VRUH HARI INI. Unduh & filter ISIC, finalisasi CSV Polesie, siapkan Derm7pt. | Manifest CSV, fold di-*freeze* |
| **2** (10–16) | Pipeline preprocessing + ablasi. Latih Baseline flat multiclass. | Skenario A selesai |
| **3** (17–23) | Stage 1 + Stage 2 | Skenario B selesai |
| **4** (24–30) | MC Dropout, semua skor uncertainty, kurva risk–coverage | Skenario C + pembanding |
| **5** (31 Ags–6 Sep) | Zero-shot Kawahara. Repeated CV multi-seed. Uji statistik. | Tabel utama Bab 4 |
| **6** (7–13 Sep) | Grad-CAM++, analisis sampel ter-reject. **Code freeze 13 Sep.** | Semua figur |
| **7–8** (14–30 Sep) | Penulisan Bab 4–5, revisi | Naskah |

Dua aturan: **mulai menulis Bab 3 dari Minggu 1**, dan **jangan sentuh kode setelah 13 September**.

<div style="page-break-after: always;"></div>
# Bagian 2 — Repositori GitHub Paper Rujukan sebagai Referensi {#bagian-2}

## Pertanyaan

> https://github.com/jpdominguez/Breslow_Melanoma_DeepLearning/tree/main — saya ingin menggunakan code-code program di sini untuk thesis saya sebagai referensi pembuatannya, namun disesuaikan dengan penelitian saya itu, gimana menurutmu?

## Jawaban

Verdict singkat: **ya, pakai — tapi sebagai kerangka acuan, bukan sebagai basis yang Anda fork lalu tambal.**

### Apa yang sebenarnya ada di dalamnya

Isi repo cuma empat item di root: folder `src`, `.gitignore`, `LICENSE`, `README.md`, dan `Supplementary_material.pdf` — total 12 commit, 0 star.

Strukturnya:

- `src/full_supervision/train/train_supervised.py`
- `src/full_supervision/test/test_supervised.py`
- `src/full_supervision/test/test_external_data.py`
- `src/semi_supervision/Annotator.py` (pseudo-anotasi via majority voting)
- `src/semi_supervision/train_student.py`
- `src/semi_supervision/test_semisupervised.py`

Argumen CLI: `-m` menerima densenet121, resnet50, vgg16, inceptionv3; `-t` menerima Breslow, InSitu, Multiclass; `-d` untuk dataset evaluasi (all, rocio, Polesie, Argenciano, ISIC).

Tiga catatan:

**Pertama, `-t Multiclass` sudah ada.** Skenario A praktis gratis — menghemat satu minggu penuh.

**Kedua, opsi `-d Argenciano` (typo dari Argenziano = dataset Kawahara) mengonfirmasi analisis sebelumnya**: Kawahara memang berada di dalam pipeline cross-validation mereka.

**Ketiga, yang TIDAK ada di repo itu banyak:** tidak ada `requirements.txt`, tidak ada CSV manifest atau definisi fold, tidak ada dataset loader siap pakai, tidak ada bobot terlatih, tidak ada notebook. Anda tetap harus membangun lapisan data dari nol.

### Dua blocker yang harus diselesaikan di hari pertama

**1. PyTorch 1.8.2 tidak akan jalan di RTX 4060.** Paper memakai Python 3.9.7 + PyTorch 1.8.2 di NVIDIA A100. RTX 4060 adalah Ada Lovelace (sm_89) yang butuh CUDA 11.8+ dan PyTorch 2.x. Kalau Anda replikasi environment mereka persis, Anda akan dapat error `no kernel image is available for execution on the device`.

**2. Lisensinya GPL-3.0, bukan MIT.** Implikasi nyata:

- Kalau Anda menyalin kode mereka dan **mendistribusikan** hasilnya, karya turunan Anda **wajib berlisensi GPL-3.0** dan wajib menyertakan source code lengkap.
- Harus mempertahankan copyright notice dan menyatakan bagian mana yang dimodifikasi.
- Kalau Anda menulis ulang dari nol dengan hanya membaca konsepnya, tidak ada kewajiban GPL — tapi tetap wajib sitasi akademik.

Saran: **taruh kode turunan mereka di satu folder terpisah** (`src/reference_dominguez/`) dengan LICENSE GPL-3.0 dan header atribusi.

### Peta reuse vs tulis ulang

| Komponen | Keputusan | Alasan |
|---|---|---|
| Struktur argparse & konvensi `N_EXP` | **Adopsi** | Sudah rapi |
| Head modifikasi (Dense 128 → output) | **Adopsi persis** | Membuat arsitektur comparable |
| Class weighting (`compute_class_weight`) | **Adopsi** | Data tetap imbalance |
| Early stopping (patience 5), save-on-best-val-loss | **Adopsi** | Standar |
| Augmentasi Albumentations (rot90, hflip, vflip @ p=0.5) | **Adopsi** | Jaga apple-to-apple |
| Training loop supervised | **Adopsi + modifikasi** | Tambah AMP + PyTorch 2.x API |
| `-t Multiclass` untuk Skenario A | **Jalankan apa adanya** | Baseline gratis |
| Data loader & path handling | **Tulis ulang** | Path hardcoded ke server mereka |
| Logika split fold | **Tulis ulang** | Harus patient-level dan di-*freeze* |
| Script test | **Tulis ulang total** | Lihat bawah |
| `Annotator.py` + `train_student.py` (SSL) | **Abaikan dulu** | Di luar critical path |
| MC Dropout, gatekeeper, inferensi hierarkis, risk-coverage | **Tulis dari nol** | Tidak ada di repo — ini kontribusi Anda |

### Refactor tunggal yang paling menentukan

Script test mereka menghitung metrik lalu mencetak ringkasan. **Jangan tiru pola ini.** Ubah semua jalur inferensi agar tugasnya cuma satu: **menulis prediksi per-gambar ke CSV.**

```
image_id, patient_id, source_dataset, fold,
y_true_mis_miv, y_true_bt, y_true_3class,
p_miv,                       # prob Stage 1 (mean of T passes)
p_bt,                        # prob Stage 2 (mean of T passes)
var_epistemic_s1, var_aleatoric_s1, entropy_s1, msp_s1, mutual_info_s1,
mc_samples_s1                # T=30 nilai mentah
```

Kenapa krusial: begitu CSV ini ada, **seluruh Bab 4 menjadi pekerjaan pandas offline yang tidak butuh GPU sama sekali.** Anda bisa mengulang analisis 50 kali dalam semalam tanpa melatih ulang apa pun. Dengan tenggat dua bulan, ini perbedaan antara selesai dan tidak.

### Struktur yang disarankan

```
thesis-breslow/
├── data/
│   ├── manifest.csv              # single source of truth
│   └── folds_frozen.json         # patient-level, di-commit ke git
├── src/
│   ├── reference_dominguez/      # GPL-3.0, atribusi jelas
│   │   └── train_supervised.py   # diadaptasi ke PyTorch 2.x
│   ├── data/dataset.py
│   ├── models/mc_dropout.py
│   ├── inference/predict.py      # → dumps CSV
│   └── analysis/                 # murni pandas, no GPU
│       ├── risk_coverage.py
│       ├── gatekeeper.py
│       └── hierarchical_eval.py
└── results/predictions/
```

### Urutan eksekusi 10 hari ke depan

1. **Hari 1:** Kirim permintaan dataset VRUH. Baca `train_supervised.py` dan `test_supervised.py` baris demi baris.
2. **Hari 2:** Bangun environment PyTorch 2.x, verifikasi `torch.cuda.get_device_capability()` mengembalikan `(8, 9)`.
3. **Hari 3–4:** Susun `manifest.csv`, bekukan fold.
4. **Hari 5–6:** Adaptasi training loop, jalankan `Multiclass` sebagai Skenario A.
5. **Hari 7–8:** Bangun `predict.py` yang mengeluarkan CSV lengkap.
6. **Hari 9–10:** Tulis modul analisis offline dengan data dummy.

Poin nomor 6 sengaja di awal: **bangun pipeline analisis sebelum data lengkap datang.**

<div style="page-break-after: always;"></div>

# Bagian 3 — Kode Pipeline & Pertanyaan Penyimpanan Model {#bagian-3}

## Pertanyaan

> Kalau ini code program dari Claude sebelumnya, apakah bisa jadi referensi juga? Dan tadi saya coba running hasilnya 100% semua. Kemudian misal nanti saya mau bikin banyak gambar visualisasi seperti grad-cam dkk seperti GitHub Juan dan grafik-grafik lainnya, itu bisa dilakukan asal udah ada save modelnya ya, misal `.pt`? Jadi aman & tidak perlu training berulang lagi, atau harus selama proses training itu sudah disiapkan semua code program untuk visualisasinya?

**Berkas terlampir:** `pipeline_lib.py`, `stage_1.ipynb`, `stage_2.ipynb`, `README.md`, `test_logic.py`

## Jawaban

Bisa, dan `pipeline_lib.py` ini **basis yang lebih baik daripada repo Juan** untuk kebutuhan Anda — config-driven, MC-Dropout dan gatekeeper sudah ada, Grad-CAM++ sudah ada, plot ROC/CM/histogram sudah ada. Repo Juan tidak punya satu pun dari itu.

### "Hasilnya 100% semua" — hati-hati menafsirkan ini

`test_logic.py` menjalankan pipeline dengan **torch yang di-stub** (palsu). `torch.nn`, `torch.optim`, `torchvision` semuanya diganti objek kosong. Yang benar-benar diuji cuma empat hal: derivasi label, rumus metrik, aritmetika persentil, dan jumlah fold.

Artinya, tes itu **secara struktural tidak mampu** mendeteksi: apakah training jalan, apakah MC-Dropout benar, apakah ada kebocoran data, apakah Grad-CAM menempel ke layer yang benar. Jangan laporkan ini ke pembimbing sebagai validasi pipeline.

### Tiga hal yang wajib diperbaiki sebelum training pertama

**1. Kebocoran data patient-level — paling serius.**

```python
def stratified_folds(df, stratify_col, cfg):
    skf = StratifiedKFold(n_splits=cfg.n_folds, shuffle=True, random_state=cfg.seed)
```

`StratifiedKFold` biasa, membagi **per-baris**. Tidak ada kolom `patient_id` di mana pun. Padahal VRUH punya 868 gambar dari hanya 316 kasus. Tanpa grouping, **AUC Anda akan terlihat bagus secara palsu**.

```python
from sklearn.model_selection import StratifiedGroupKFold

def stratified_folds(df, stratify_col, cfg):
    sgkf = StratifiedGroupKFold(n_splits=cfg.n_folds, shuffle=True,
                                random_state=cfg.seed)
    y = df[stratify_col].astype(int).values
    groups = df["patient_id"].values
    for k, (tr, va) in enumerate(sgkf.split(np.zeros(len(df)), y, groups)):
        yield k, df.iloc[tr].reset_index(drop=True), df.iloc[va].reset_index(drop=True)
```

Tambahkan assertion: `assert set(train.patient_id) & set(val.patient_id) == set()`.

**2. `fillna(0.0)` diam-diam merusak label.**

```python
df["breslow_mm"] = pd.to_numeric(df["breslow_mm"], errors="coerce").fillna(0.0)
df["is_invasive"] = (df["breslow_mm"] > 0.0).astype(int)
```

Kombinasi `errors="coerce"` + `fillna(0.0)` berarti **setiap nilai yang gagal diparse otomatis menjadi Mis.** Metadata ISIC sering berisi rentang teks. Ganti agar eksplisit: parse, hitung NaN, **cetak jumlahnya**, lalu putuskan sadar.

**3. Polesie dan Kawahara belum ada.** `build_label_frame()` baru menangani VRUH + ISIC.

### Cukup `.pt` saja?

Jawaban singkat: **ya, tapi `.pt` saja tidak cukup.**

| Visualisasi | Butuh apa | Aman dibuat belakangan? |
|---|---|---|
| **Grad-CAM++** | bobot + 1 gambar | Ya, sepenuhnya |
| ROC, confusion matrix | prediksi per-sampel di val fold | Ya, **asal split fold identik** |
| Histogram uncertainty, risk–coverage | skor MC per-sampel | Sama |
| Kurva loss/akurasi per epoch | riwayat training | **Hilang selamanya kalau tidak disimpan** |

**Jebakannya:** `save_checkpoint()` hanya menyimpan `model.state_dict()`. Sementara fold dibangkitkan ulang dari `StratifiedKFold(random_state=seed)` **atas urutan baris `df`**. Kalau bulan depan Anda menambah satu gambar ISIC atau memperbaiki `fillna`, urutan `df` berubah → pembagian fold berubah → checkpoint "fold 0" dievaluasi pada sampel yang dulu ada di **training set**-nya.

Hasilnya tidak error. Grafiknya tetap tercetak rapi. Angkanya cuma jadi lebih tinggi dan tidak valid — jenis bug paling berbahaya karena tak terlihat.

### Tiga artefak yang harus disiapkan saat training

**(a) Pembagian fold yang dibekukan ke disk:**

```python
df["fold"] = -1
for k, tr, va in stratified_folds(df, "is_invasive", cfg):
    df.loc[df.img_path.isin(va.img_path), "fold"] = k
df.to_csv(os.path.join(cfg.output_dir, "manifest_frozen.csv"), index=False)
```

**(b) Checkpoint dengan metadata:**

```python
def save_checkpoint(model, cfg, name, fold=None, history=None, val_ids=None):
    path = os.path.join(cfg.output_dir, f"{name}.pt")
    torch.save({"state_dict": model.state_dict(),
                "config": asdict(cfg), "fold": fold,
                "history": history, "val_img_paths": val_ids}, path)
    return path
```

**(c) Dump prediksi ke CSV.**

### Ringkasnya

Anda **tidak perlu** menulis semua kode visualisasi sebelum training. Yang perlu dipastikan sebelum menekan tombol train: **fold dibekukan ke disk, checkpoint membawa metadata + history, dan prediksi per-sampel di-dump ke CSV.**

<div style="page-break-after: always;"></div>
# Bagian 4 — Verifikasi Metadata Dataset & Blueprint Final {#bagian-4}

## Pertanyaan

> Seluruh datasetnya sudah saya kumpulkan, dan berikut seluruh metadatanya yang saya simpan di `D:\REGAN-Projek\THESIS\Dataset` (ada folder ISIC, Kawahara, Polesei, dan VRUH). Sekarang coba jabarkan lagi dengan detail rancangan penelitian thesis saya yang fix.

**Berkas terlampir:** `VRUH_dataset_cleaned.csv`, `ISIC_breslow_metadata.csv`, `kawahara_meta.csv`, `polesie_ground_truth.csv`

## Jawaban

Empat temuan dari verifikasi metadata aktual:

### 1. Ekstraksi data Anda terbukti benar

Polesie 193 gambar / 184 kasus dan Kawahara 247 melanoma (setelah membuang 4 metastasis + 1 tanpa keterangan) **cocok persis** dengan angka paper Dominguez-Morales. Ini bukti kuat untuk Bab 3.

### 2. ISIC tidak punya satu pun kasus in situ

Minimum 0.2 mm, nol Mis. Penyebabnya logis: filter mensyaratkan metadata ketebalan, sedangkan in situ tidak punya nilai itu. Konsekuensinya berat — **semua 555 gambar ISIC berlabel invasif**, sehingga Stage 1 bisa mencapai akurasi tinggi hanya dengan mengenali "ini gaya ISIC → invasif". Itu *domain shortcut*, bukan pembelajaran klinis.

### 3. 58% ISIC bernilai tepat 0.8 mm

323 dari 555 gambar. Persis di batas keputusan Stage 2, dengan presisi yang meragukan — hampir pasti artefak pembulatan.

### 4. VRUH punya `patient_id`, dan Anda membutuhkannya

860 gambar dari hanya 314 pasien — rata-rata 2,74, maksimum 13 gambar per pasien.

---

## Komposisi Dataset Terverifikasi

| Sumber | Gambar | Pasien/Kasus | Mis | Miv&lt;0.8 | Miv≥0.8 | Peran |
|---|---|---|---|---|---|---|
| **VRUH** | 860 | 314 | 202 | 343 | 315 | Latih + Validasi |
| **Polesie** | 193 | 184 | 76 | 68 | 49 | Latih + Validasi |
| **ISIC** | 555 | 555 | **0** | 53 | 502 | Latih (disubsampel) |
| **Kawahara** | 247 | 247 | 64 | 102* | 81* | **Uji eksternal (dikunci)** |

\* Kawahara memakai ambang AJCC ke-7 (0.76 mm).

### Keputusan subsampling ISIC

Ambil **53 gambar &lt;0.8 mm (seluruhnya) + 100 gambar ≥0.8 mm (acak, seed tetap)**, prioritas yang **bukan** bernilai tepat 0.8 mm.

| Kelas | VRUH | Polesie | ISIC | **Total** |
|---|---|---|---|---|
| Mis | 202 | 76 | 0 | **278** |
| Miv &lt; 0.8 mm | 343 | 68 | 53 | **464** |
| Miv ≥ 0.8 mm | 315 | 49 | 100 | **464** |
| | | | | **1.206 gambar / ~651 kasus** |

### Ambiguitas label Polesie

| Rentang | n | Pemetaan |
|---|---|---|
| 0 mm (In situ) | 76 | Mis |
| 0.1–0.5 mm | 41 | Miv &lt; 0.8 |
| **0.6–0.8 mm** | **27** | **Miv &lt; 0.8 — ambigu** |
| 0.9–1.0 mm | 15 | Miv ≥ 0.8 |
| 1.1–2.0 mm | 19 | Miv ≥ 0.8 |
| 2.1–4.0 mm | 10 | Miv ≥ 0.8 |
| &gt; 4 mm | 5 | Miv ≥ 0.8 |

Bucket 0.6–0.8 mm (14% dari Polesie) melintasi batas keputusan. Pertahankan pemetaan ke &lt;0.8, **deklarasikan eksplisit**, dan jalankan analisis sensitivitas.

---

## Ringkasan Blueprint Final

### Arsitektur

| Komponen | Pilihan | Alasan |
|---|---|---|
| Backbone | **DenseNet-121** (utama), ResNet-50 (pembanding) | `drop_rate` tertanam di dense block → MC Dropout mengambil sampel dari ruang bobot lebih dalam |
| Bobot awal | ImageNet | Sesuai paper rujukan |
| Head | Dense 128 → output | **Identik dengan paper** |
| Ketidakpastian | **MC Dropout, T = 30** | Pilih satu; Flipout dibuang demi tenggat |
| Input | 224 × 224 | Sesuai paper |

### Dekomposisi ketidakpastian

Dengan T forward pass menghasilkan probabilitas p&#8348;:

- **Epistemik:** Var[p] = (1/T) &Sigma;&#8348; (p&#8348; &minus; p&#772;)&sup2;
- **BALD:** H[p&#772;] &minus; (1/T) &Sigma;&#8348; H[p&#8348;]
- **Aleatorik:** (1/T) &Sigma;&#8348; H[p&#8348;]

Gatekeeper menggunakan komponen **epistemik**, karena ketidakpastian aleatorik tidak dapat dikurangi dengan merujuk ke dokter.

### Pipeline

```
                                    ┌─────────────────────────┐
   Citra ──► Stage 1 ──► Mis ──────►│  Prediksi: In situ      │
             (MC Dropout, T=30)     └─────────────────────────┘
                  │
                  └──► Miv ──► Gatekeeper: var_epistemik > tau ?
                                    │
                          YA ───────┴─────── TIDAK
                          ▼                    ▼
                 ┌────────────────┐    ┌──────────────┐
                 │ REJECT —       │    │  Stage 2     │
                 │ Tinjauan       │    │ <0.8 / >=0.8 │
                 │ Dermatolog     │    └──────────────┘
                 └────────────────┘
```

Dua perbaikan desain:

**a. Gatekeeper simetris** — tolak setiap sampel dengan ketidakpastian epistemik tinggi ke arah mana pun, karena eror paling fatal justru Miv ≥0.8 yang diprediksi Mis.

**b. Stage 2 dilatih pada prediksi out-of-fold** Stage 1, bukan label asli — menutup mismatch train/inference.

### Skenario eksperimen

| Kode | Sistem | Menguji |
|---|---|---|
| **A** | Flat multiclass 3-kelas | Baseline |
| **A-rej** | Flat multiclass + penolakan | **Kontrol wajib** — memisahkan efek hierarki dari efek penolakan |
| **B** | Dual-stage tanpa gatekeeper | Apakah dekomposisi hierarkis membantu? |
| **C** | Dual-stage + gatekeeper epistemik | Apakah penolakan menekan perambatan eror? |

### Daftar deklarasi wajib di Bab 3

1. ISIC tidak menyumbang kasus in situ; disubsampel untuk mencegah *source–label confounding*.
2. 58% ISIC bernilai tepat 0.8 mm — diduga artefak pembulatan.
3. Polesie bucket 0.6–0.8 mm (27 gambar) ambigu terhadap batas keputusan.
4. Kawahara memakai proxy AJCC ke-7 (0.76 mm); kasus di pita 0.76–0.80 mm salah dilabeli.
5. Kawahara dikunci penuh — berbeda dari paper rujukan yang memasukkannya ke CV.
6. Perbandingan dilakukan terhadap **jalur supervised** paper rujukan.
7. MC Dropout pada DenseNet mengambil sampel dari dense block; pada ResNet-50 hanya dari head.
8. Ulceration dan T-stage hanya ada pada VRUH; T-stage diturunkan dari Breslow → kebocoran label.

<div style="page-break-after: always;"></div>

# Bagian 5 — Pembangkitan Codebase Lengkap {#bagian-5}

## Pertanyaan

> Oke, sekarang generate semua file yang saya butuhkan untuk penelitian saya tersebut, dengan lengkap dan detail, serta petunjuk alurnya yang mana saja file yang harus saya jalankan terlebih dahulu — misal dari file preprocessing data kalau pisah, file bikin path tiap dataset, atau training dulu, dan sebagainya. Ingat agar menyertakan save model untuk menyimpan modelnya, file-file visualisasi, file-file CSV yang dibutuhkan agar tidak training ulang, dsb. Serta tambahkan juga wandb untuk penyimpanan hasil tambahan & analisis.

**Berkas terlampir:** `conda list` dari environment `torch-gpu`

## Jawaban

Environment terverifikasi kompatibel: torch 2.5.1+cu121, torchvision 0.20.1+cu121, albumentations 2.0.8, numpy 2.0.2, pandas 2.3.3, scikit-learn 1.6.1, wandb 0.25.0, opencv 4.10, Python 3.9.24.

Codebase dibangkitkan: **24 file, ~3.450 baris**, semua lolos kompilasi.

### Urutan menjalankan

```bash
# 1. SEKALI DI AWAL
python run_check_setup.py            # cek GPU, library, dan apakah gambar ketemu
python run_00_build_manifest.py      # -> manifest_frozen.csv  <- COMMIT KE GIT
python run_01_preprocess_cache.py    # -> cache raw_224 & proc_224

# 2. TRAINING
python run_02_train_stage1.py
python run_03_train_stage2.py --mode both
python run_04_train_flat.py

# 3. EKSTERNAL (Kawahara baru dibuka di sini)
python run_05_external_kawahara.py

# 4. ANALISIS & FIGUR - TANPA GPU
python run_06_analysis.py
python run_07_visualize.py
python run_08_gradcam.py

# 5. ABLASI
python run_09_ablations.py --what plan
python run_09_ablations.py --what shortcut
```

### Peta file

| File | Peran |
|---|---|
| `config.py` | **Satu-satunya** tempat mengedit path & hyperparameter |
| `src/paths.py` | Resolver path gambar 4 sumber (dengan indeks fallback) |
| `src/manifest.py` | Bangun manifest, label, patient_id, subsample ISIC, fold beku |
| `src/preprocessing.py` | Hair removal, Shades of Gray (p=6), border crop |
| `src/data.py` | Dataset, transform, split fold, cache |
| `src/models.py` | Backbone + head Dense-128, `enable_mc_dropout()` |
| `src/uncertainty.py` | MC-Dropout, dekomposisi epistemik/aleatorik, BALD, MSP |
| `src/metrics.py` | Metrik, risk-coverage, AURC, Wilcoxon, bootstrap CI |
| `src/selective.py` | Kalibrasi ambang bersarang, gatekeeper, perakitan 3-kelas |
| `src/engine.py` | Loop training: AMP, class weight, early stopping |
| `src/checkpoint.py` | Simpan/muat checkpoint **bermetadata + history** |
| `src/plots.py` | Semua figur Bab 4 |
| `src/gradcam.py` | Grad-CAM++ |
| `src/wb.py` | Wrapper wandb yang tidak pernah menggagalkan run |

### Keluaran

```
data/manifest_frozen.csv              <- sumber kebenaran, COMMIT
cache/{raw,proc}_224/                 <- citra terproses
checkpoints/*.pt                      <- bobot + config + history + val paths
predictions/*.csv                     <- prediksi per-sampel + skor ketidakpastian
results/*.csv                         <- tabel Bab 4
figures/*.png|pdf                     <- figur Bab 4
```

### Yang menjawab kekhawatiran soal training ulang

**Checkpoint bermetadata.** Setiap `.pt` menyimpan `state_dict` + config lengkap + `history` (kurva loss/akurasi per epoch) + daftar `val_img_paths` + fold + seed.

**CSV prediksi per-sampel.** Setiap inferensi menulis satu baris per gambar berisi probabilitas, `var_epistemic`, `bald`, `entropy_total`, `entropy_aleatoric`, `msp`, dan **30 nilai mentah MC-Dropout**. Konsekuensinya: `run_06` dan `run_07` sama sekali tidak menyentuh GPU. Anda bisa mengganti `reject_percentile` dari 10% ke 15%, menukar `variance` ke `bald`, atau mengubah `gatekeeper_mode` — lalu jalankan ulang `run_06` saja. Detik, bukan jam.

**Grad-CAM++** (`run_08`) menghasilkan tiga grid: prediksi benar-yakin, prediksi salah, dan **kasus yang ditolak gatekeeper**. Grid ketiga paling berharga di sidang.

### Tiga hal yang tertanam

`assign_folds()` memakai `StratifiedGroupKFold` pada `patient_id` dengan **assertion yang gagal keras** kalau ada pasien muncul di train dan val.

`run_06` otomatis menjalankan **A-rej** dan membandingkan lima skor ketidakpastian — acak, MSP, entropy, variance, BALD — pada coverage yang sama, lengkap dengan AURC dan AUROC deteksi eror.

Ambang gatekeeper dikalibrasi dari inner-val lalu dibekukan ke test. Output `run_06` mencetak **coverage aktual** yang tidak persis 90% — itu angka yang dilaporkan.

<div style="page-break-after: always;"></div>
# Lampiran {#lampiran}

## Lampiran A — Berkas yang Dipertukarkan

| Putaran | Berkas | Jenis |
|---|---|---|
| 1 | `Melanoma_Breslow_Thickness_Classification...pdf` | Paper rujukan (IEEE JBHI 2025) |
| 1 | Dua dokumen rancangan tesis (draft blueprint) | Teks tempel |
| 3 | `pipeline_lib.py`, `stage_1.ipynb`, `stage_2.ipynb`, `README.md`, `test_logic.py` | Kode iterasi sebelumnya |
| 4 | `VRUH_dataset_cleaned.csv` (860 baris, 8 kolom) | Metadata |
| 4 | `ISIC_breslow_metadata.csv` (555 baris, 2 kolom) | Metadata |
| 4 | `kawahara_meta.csv` (1011 baris, 19 kolom) | Metadata |
| 4 | `polesie_ground_truth.csv` (193 baris, 5 kolom) | Metadata |
| 5 | `conda list` environment `torch-gpu` | Spesifikasi lingkungan |

**Keluaran yang dihasilkan:**

- `blueprint_tesis_final.md` — rancangan penelitian final
- `thesis-breslow.zip` — codebase lengkap (24 file, ~3.450 baris)

---

## Lampiran B — Rekap Keputusan Desain

| # | Keputusan | Alasan |
|---|---|---|
| 1 | Kawahara dikunci sebagai zero-shot hold-out | Lebih ketat dari paper rujukan; harus dinyatakan sebagai deviasi disengaja |
| 2 | Supervised-only, SSL dibuang dari critical path | Kebersihan eksperimen; hanya hierarki + gatekeeper yang diuji |
| 3 | DenseNet-121 sebagai backbone utama | Dropout tertanam di dense block → MC sampling lebih dalam |
| 4 | MC Dropout saja, Flipout/Blitz dibuang | Sederhana, murah, mudah dipertahankan |
| 5 | Gatekeeper simetris | Eror Miv≥0.8 → Mis paling fatal secara klinis |
| 6 | Stage 2 dilatih pada prediksi out-of-fold | Menutup mismatch train/inference |
| 7 | ISIC disubsampel ke 153 gambar | Mencegah source-label confounding |
| 8 | Ambang dikalibrasi dari inner-val, dibekukan | Anti kebocoran; laporkan coverage aktual |
| 9 | Skenario A-rej sebagai kontrol wajib | Memisahkan efek hierarki dari efek penolakan |
| 10 | Preprocessing sebagai ablasi, bukan asumsi | Inpainting bisa merusak tekstur dermoskopik halus |
| 11 | Shades of Gray (p=6) menggantikan Gray-World | Konsisten lebih unggul di literatur dermoskopi |
| 12 | 5 fold × 5 seed | Memungkinkan uji Wilcoxon; komputasi tersedia |
| 13 | AMP dinyalakan tapi tidak diklaim sebagai kontribusi | Trivial pada skala data ini |
| 14 | Novelty diposisikan aplikatif-empiris | Menghindari serangan yang tidak perlu |

---

## Lampiran C — Struktur Codebase

```
thesis-breslow/
├── README.md
├── requirements.txt
├── config.py                       # satu-satunya tempat edit path & hyperparameter
├── run_check_setup.py              # verifikasi GPU, library, resolusi path gambar
├── run_00_build_manifest.py        # -> manifest_frozen.csv
├── run_01_preprocess_cache.py      # -> cache raw_224 & proc_224
├── run_02_train_stage1.py          # Stage 1 + dump MC-Dropout
├── run_03_train_stage2.py          # Stage 2 (mode gt & oof)
├── run_04_train_flat.py            # Skenario A (flat multiclass)
├── run_05_external_kawahara.py     # inferensi zero-shot
├── run_06_analysis.py              # tabel A/A-rej/B/C, AURC, Wilcoxon (tanpa GPU)
├── run_07_visualize.py             # semua figur (tanpa GPU)
├── run_08_gradcam.py               # Grad-CAM++
├── run_09_ablations.py             # ablasi + diagnostik source shortcut
└── src/
    ├── __init__.py
    ├── paths.py                    # resolver path 4 sumber dataset
    ├── manifest.py                 # label, patient_id, subsample ISIC, fold beku
    ├── preprocessing.py            # hair removal, Shades of Gray, border crop
    ├── data.py                     # Dataset, transform, split fold, cache
    ├── models.py                   # backbone, head Dense-128, enable_mc_dropout
    ├── uncertainty.py              # MC-Dropout, epistemik/aleatorik, BALD, MSP
    ├── metrics.py                  # metrik, risk-coverage, AURC, Wilcoxon, bootstrap
    ├── selective.py                # kalibrasi ambang bersarang, gatekeeper
    ├── engine.py                   # training loop: AMP, class weight, early stop
    ├── checkpoint.py               # checkpoint bermetadata + history
    ├── plots.py                    # figur Bab 4
    ├── gradcam.py                  # Grad-CAM++
    └── wb.py                       # wrapper wandb
```

---

## Lampiran D — Linimasa Eksekusi

| Minggu | Periode | Fokus | Deliverable |
|---|---|---|---|
| **1** | 3–9 Ags | Perbaiki cacat pipeline; bangun manifest 4 sumber; subsampel ISIC; bekukan fold; verifikasi environment | Manifest final + assertion anti-bocor lolos |
| **2** | 10–16 Ags | Preprocessing + ablasi; latih Skenario A; harness evaluasi 3×3; dump CSV | Angka pertama di tangan |
| **3** | 17–23 Ags | Stage 1 + Stage 2 (versi GT dan OOF) | Skenario B selesai |
| **4** | 24–30 Ags | MC Dropout T=30, semua skor ketidakpastian, kalibrasi ambang bersarang | Skenario C + A-rej + pembanding |
| **5** | 31 Ags–6 Sep | Uji eksternal Kawahara; 5 seed × 5 fold; uji statistik | Tabel utama Bab 4 final |
| **6** | 7–13 Sep | Grad-CAM++, analisis sampel tertolak, ablasi sisa | Semua figur. **Code freeze 13 Sep** |
| **7–8** | 14–30 Sep | Penulisan Bab 4–5, revisi pembimbing | Naskah |

**Dua aturan yang dipegang mati-matian:**

1. **Tulis Bab 3 mulai Minggu 1.** Metodologi tidak perlu menunggu hasil.
2. **Jangan sentuh kode setelah 13 September**, apa pun hasilnya. Hasil "kurang bagus" yang dianalisis jujur jauh lebih aman di sidang daripada hasil bagus yang tidak sempat ditulis.

---

## Lampiran E — Catatan Pertahanan Sidang

**Kebocoran data.** Split memakai `StratifiedGroupKFold` pada `patient_id`. VRUH punya 860 gambar dari hanya 314 pasien (rata-rata 2,74, maksimum 13). Ada assertion yang gagal keras bila bocor.

**MC Dropout yang benar.** `enable_mc_dropout()` membekukan BatchNorm dan hanya mengaktifkan Dropout. Memanggil `model.train()` secara naif akan merusak statistik running BatchNorm dan membuat estimasi ketidakpastian tidak valid.

**Sirkularitas gatekeeper.** Membuang 10% sampel paling tidak pasti hampir selalu menaikkan akurasi — untuk metrik apa pun. Karena itu perbandingan dilakukan pada coverage yang sama melawan penolakan acak, MSP, entropy, variance, dan BALD, dengan metrik AURC dan AUROC deteksi eror.

**Jika MC variance tidak mengungguli MSP**, itu tetap temuan yang layak dilaporkan: 30× biaya komputasi tidak sepadan pada skala data ini. Temuan negatif yang dianalisis jujur jauh lebih aman daripada klaim positif yang rapuh.

**Lisensi.** Repo `jpdominguez/Breslow_Melanoma_DeepLearning` berlisensi GPL-3.0. Bila kode turunannya didistribusikan, karya turunan wajib GPL-3.0 dan menyertakan source lengkap.

**Environment.** Paper rujukan memakai PyTorch 1.8.2 pada NVIDIA A100. RTX 4060 adalah Ada Lovelace (sm_89) yang membutuhkan CUDA 11.8+ dan PyTorch 2.x — jangan mereplikasi environment mereka.

---

*Dokumen ini adalah transkrip terstruktur dari diskusi perancangan tesis pada 3 Agustus 2026. Seluruh angka dataset diverifikasi langsung dari berkas metadata yang dilampirkan peneliti.*
